import os
import sys
import zipfile
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("falcon_cloud")

curr_dir = os.path.dirname(os.path.abspath(__file__))
zip_path = os.path.join(curr_dir, "app.zip")
app_dir = os.path.join(curr_dir, "app")

# 1. Extract app.zip unconditionally to ensure the latest code is always used
if os.path.exists(zip_path):
    try:
        logger.info(f"Extracting latest {zip_path} to {curr_dir}...")
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(curr_dir)
        logger.info("Extraction complete.")
    except Exception as ze:
        logger.error(f"Error extracting app.zip: {ze}")

# 2. Ensure __init__.py exists in app folder
if os.path.exists(app_dir):
    init_p = os.path.join(app_dir, "__init__.py")
    if not os.path.exists(init_p):
        with open(init_p, "w", encoding="utf-8") as f:
            f.write("# falcon app package\n")

if curr_dir not in sys.path:
    sys.path.insert(0, curr_dir)

try:
    import spaces
    has_spaces = True
except ImportError:
    spaces = None
    has_spaces = False

import gradio as gr
import threading
import asyncio
from app.tracker import run_smc_tracker_loop
from app.telegram_service import TelegramService
from app.database import SessionLocal
from app.models import PreferenceModel
import json

# Start background 24/7 tracker in a dedicated daemon thread with its own event loop
def _start_tracker_thread():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(run_smc_tracker_loop())
    except Exception as e:
        logger.error(f"Error in SMC tracker thread: {e}")

try:
    tracker_thread = threading.Thread(target=_start_tracker_thread, daemon=True, name="FalconTracker")
    tracker_thread.start()
    logger.info("Background Falcon 24/7 Tracker daemon thread started successfully.")
except Exception as e:
    logger.error(f"Error launching tracker thread: {e}")

# ZeroGPU requirement: direct top-level @spaces.GPU function
if has_spaces:
    @spaces.GPU(duration=60)
    def check_falcon_status(btn_click):
        return f"🦅 Falcon ZeroGPU AI Core Active & Synchronized: {btn_click}"
else:
    def check_falcon_status(btn_click):
        return f"🦅 Falcon AI Core Active & Synchronized: {btn_click}"

async def test_telegram():
    try:
        msg = (
            "🦅 <b>Falcon 24/7 Cloud Engine Online!</b>\n\n"
            "Hugging Face Spaces scanner is now live and monitoring 21 Falcon coins 24/7.\n"
            "High confluence setups (>=80%) will be alerted here instantly!"
        )
        success = await TelegramService.send_message(msg)
        if success:
            return "✅ Telegram alert sent successfully! Check your Telegram app."
        else:
            return "❌ Failed to send Telegram alert. Check your Bot Token and Chat ID."
    except Exception as ex:
        return f"❌ Error: {ex}"

def get_watchlist_data():
    db = SessionLocal()
    try:
        pref = db.query(PreferenceModel).filter(PreferenceModel.key == "smc_monitored_coins").first()
        if pref and pref.value:
            coins = json.loads(pref.value)
            data = []
            for c in coins:
                data.append([
                    c.get("symbol", ""),
                    c.get("timeframe", "5m"),
                    f"{c.get('confidence', 0)}%",
                    "READY" if c.get("is_valid") else "MONITORING",
                    str(c.get("entryPrice") or (c.get("last_result", {}).get("entry_price_area") if isinstance(c.get("last_result"), dict) else None) or "Waiting pullback..."),
                    str(c.get("stopLoss") or "-"),
                    str(c.get("takeProfit") or "-")
                ])
            return data
    except Exception as e:
        logger.error(f"Error loading watchlist: {e}")
    finally:
        db.close()
    return []

def sync_test_telegram():
    import asyncio
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(test_telegram())

# Create Gradio UI
with gr.Blocks(title="Falcon SMC 24/7 Cloud Engine", theme=gr.themes.Soft(primary_hue="blue")) as demo:
    gr.Markdown("""
    # 🦅 Falcon Institutional SMC 24/7 Cloud Scanner
    **Status:** 🟢 **LIVE & SCANNING 24/7** | **Engine:** Complete 24H SMC Multi-Element Scanner | **Rules:** Master Falcon Rules 1 - 76 + Break-Even (Rule 77) | **Min Confidence:** 80%
    
    This space runs in the cloud 24/7 even when your personal computer is turned off. 
    High-confluence trade confirmations (>=80%) with confirmed 1:2.0 RR targets and +1.0R Break-Even protection are instantly dispatched to your Telegram app.
    """)
    
    with gr.Row():
        test_btn = gr.Button("📲 Test Telegram Notification", variant="primary")
        status_txt = gr.Textbox(label="Telegram Test Status", interactive=False)
        
    test_btn.click(fn=sync_test_telegram, outputs=status_txt)

    with gr.Row():
        gpu_btn = gr.Button("⚡ Verify AI Hardware Status", variant="secondary")
        gpu_txt = gr.Textbox(label="Hardware Status", interactive=False)
    gpu_btn.click(fn=check_falcon_status, inputs=[gpu_txt], outputs=[gpu_txt])

    gr.Markdown("### 📊 Active Monitored Watchlist (24/7 Live Tracker)")
    watchlist_table = gr.Dataframe(
        headers=["Symbol", "Timeframe", "Confidence", "Status", "Entry Price", "Stop Loss", "Take Profit"],
        value=get_watchlist_data,
        every=5,
        interactive=False
    )

if __name__ == "__main__":
    demo.queue().launch(server_name="0.0.0.0", server_port=7860)
